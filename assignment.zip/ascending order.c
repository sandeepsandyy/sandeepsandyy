/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
*/
#include <stdio.h>
int main()
{
    int arr[8]={44,3,56,21,10,9,8,22};
    int i,n = sizeof(arr)/sizeof(arr[0]);
    printf("original elements in a n array is:");
    for(i=0;i<n;i++)
    {
        printf("%d\t",arr[i]);
    }
    int j,temp;
    for(i=0;i<n-1;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(arr[i]>arr[j])
            {
                temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
    }
    printf("\n");
    for(i=0;i<n;i++)
    {
        printf("%d\t",arr[i]);
    }
}